# CSC 365 Lab 7 - Full Power of SQL

## Author: Andrew Cheung
## Email: acheun29@calpoly.edu
